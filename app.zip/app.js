if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}

const express = require('express');
const router = express.Router()
const cookieParser = require('cookie-parser');
const cors = require('cors');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();

const logger = require('morgan');
const mongoose = require('mongoose');


const corsOptions = {
  origin: true, // Allow all origins
  methods: ['PUT', 'POST', 'PATCH', 'DELETE', 'GET'], // Allow only specific methods
  // allowedHeaders: ['Content-Type', 'Access-Control-Allow-Headers', 'Origin', 'X-Requested-With', 'Accept', 'Authorization', 'pk2'], // Allow only specific headers
  allowedHeaders: true, // Allow only specific headers
  credentials: true, // Allow credentials (cookies, etc.) to be included
};

app.use(cors(corsOptions));

app.use(cookieParser());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ limit: '70mb', extended: true }));



// app.set('trust proxy', true); // Trust X-Forwarded-For header when behind a proxy

// const allowedIPs = ['175.107.225.100','192.168.0.100', '127.0.0.1', '::1',"104.196.24.122"]; // Add your IPs here

// const ipFilter = (req, res, next) => {
//   const getClientIP = (req) => {
//     const xForwardedFor = req.headers['x-forwarded-for'];
//     if (xForwardedFor) {
//       // If there are multiple IPs in x-forwarded-for (due to proxy chaining), take the first one
//       const ips = xForwardedFor.split(',').map(ip => ip.trim());
//       return ips[0]; // First IP in the list is the actual client IP
//     }
//     return req.ip || req.connection.remoteAddress; // Fallback to request IP if no x-forwarded-for
//   };

//   const clientIP = getClientIP(req);
//   console.log(`Incoming request from IP: ${clientIP}`);


//   // Your IP filtering logic here
//   if (allowedIPs.includes(clientIP)) {
//     next();
//   } else {
//     res.status(403).json({ message: 'Access denied: Your IP is not allowed to access this API.' });
//   }

// // 
// };




// app.use(ipFilter)



// app.use('/static/files/pdfs', express.static('./pdfs'));
// app.use('/static/files/images', express.static('./images'));

const dataRoutes = require("./routes/data")
app.use("/shopify/order", dataRoutes)
// app.use("/saimShopify", dataRoutes)

  












/* *********************************** */
/*            M O N G O D B            */
/* *********************************** */
mongoose
  .connect(process.env.DatabaseURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });



const start = (port) => {
  try {
    app.listen(port, () => {
      console.log(`Server up and running at: http://localhost:${port}`);
    });
  } catch (error) {
    console.error("eeeeeee--------->", error);
    process.exit();
  }
};

start(process.env.PORT || 4005);

