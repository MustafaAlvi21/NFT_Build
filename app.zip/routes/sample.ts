

// async function createInvoicePDF2222(data) {
//     // Create a new PDFDocument
//     const pdfDoc = await PDFDocument.create();
//     const page = pdfDoc.addPage([600, 800]);

//     // Set up fonts
//     const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
//     const boldFont = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
    
//     const fontSize = 12;
//     const boldFontSize = 14;

//     // Add header content
//     page.drawText('Invoice', {
//         x: 50,
//         y: 740,
//         size: boldFontSize,
//         font: boldFont,
//         color: rgb(0, 0, 0),
//     });

//     // Add sender information (from)
//     page.drawText('From', { x: 50, y: 720, size: fontSize, font: boldFont });
//     page.drawText(data.from, { x: 50, y: 705, size: fontSize, font: timesRomanFont });
//     page.drawText('India', { x: 50, y: 690, size: fontSize, font: timesRomanFont });

//     // Add Bill to information
//     page.drawText('Bill to', { x: 200, y: 720, size: fontSize, font: boldFont });
//     page.drawText('Bob Biller'data.billingAddress.first_name, { x: 200, y: 705, size: fontSize, font: timesRomanFont });
//     page.drawText('My Company', { x: 200, y: 690, size: fontSize, font: timesRomanFont });
//     page.drawText('123 Billing Street'data.billingAddress.address1 , { x: 200, y: 675, size: fontSize, font: timesRomanFont });
//     page.drawText('Billtown KY K2P0B0'`${data.billingAddress.city} ${data.billingAddress.province} ${data.billingAddress.zip}`, { x: 200, y: 660, size: fontSize, font: timesRomanFont });
//     page.drawText('United States', { x: 200, y: 645, size: fontSize, font: timesRomanFont });

//     // Add Ship to information
//     page.drawText('Ship to', { x: 400, y: 720, size: fontSize, font: boldFont });
//     page.drawText('Steve Shipper', { x: 400, y: 705, size: fontSize, font: timesRomanFont });
//     page.drawText('Shipping Company', { x: 400, y: 690, size: fontSize, font: timesRomanFont });
//     page.drawText('123 Shipping Street', { x: 400, y: 675, size: fontSize, font: timesRomanFont });
//     page.drawText('Shippington KY 40003', { x: 400, y: 660, size: fontSize, font: timesRomanFont });
//     page.drawText('United States', { x: 400, y: 645, size: fontSize, font: timesRomanFont });
//     page.drawText('555-555-SHIP', { x: 400, y: 630, size: fontSize, font: timesRomanFont });

//     // Add Order number and date
//     page.drawText('Order #9999', { x: 400, y: 610, size: fontSize, font: timesRomanFont });
//     page.drawText('October 4, 2024', { x: 400, y: 595, size: fontSize, font: timesRomanFont });

//     // Order Details Section
//     page.drawText('Order Details', { x: 50, y: 570, size: boldFontSize, font: boldFont });
    
//     // Table Header
//     page.drawText('Qty', { x: 50, y: 550, size: fontSize, font: boldFont });
//     page.drawText('Item', { x: 100, y: 550, size: fontSize, font: boldFont });
//     page.drawText('Price', { x: 500, y: 550, size: fontSize, font: boldFont });

//     // Items
//     page.drawText('1', { x: 50, y: 530, size: fontSize, font: timesRomanFont });
//     page.drawText('Aviator sunglasses', { x: 100, y: 530, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 89.99', { x: 500, y: 530, size: fontSize, font: timesRomanFont });

//     page.drawText('1', { x: 50, y: 510, size: fontSize, font: timesRomanFont });
//     page.drawText('Mid-century lounger\nPROD5 (Rs 5.00)', { x: 100, y: 510, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 154.99', { x: 500, y: 510, size: fontSize, font: timesRomanFont });

//     // Summary Details
//     page.drawText('Subtotal', { x: 400, y: 470, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 244.98', { x: 500, y: 470, size: fontSize, font: timesRomanFont });

//     page.drawText('ORDERS', { x: 400, y: 450, size: fontSize, font: timesRomanFont });
//     page.drawText('-Rs 5.00', { x: 500, y: 450, size: fontSize, font: timesRomanFont });

//     page.drawText('Shipping', { x: 400, y: 430, size: fontSize, font: timesRomanFont });
//     page.drawText('FREE', { x: 500, y: 430, size: fontSize, font: timesRomanFont });

//     page.drawText('Total', { x: 400, y: 410, size: fontSize, font: boldFont });
//     page.drawText('Rs 239.98', { x: 500, y: 410, size: fontSize, font: timesRomanFont });

//     page.drawText('Total Paid', { x: 400, y: 390, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 0.00', { x: 500, y: 390, size: fontSize, font: timesRomanFont });

//     page.drawText('Outstanding Amount', { x: 400, y: 370, size: fontSize, font: boldFont });
//     page.drawText('Rs 239.98', { x: 500, y: 370, size: fontSize, font: timesRomanFont });

//     // Transaction Details
//     page.drawText('Transaction Details', { x: 50, y: 330, size: boldFontSize, font: boldFont });

//     // Table Header
//     page.drawText('Type', { x: 50, y: 310, size: fontSize, font: boldFont });
//     page.drawText('Amount', { x: 150, y: 310, size: fontSize, font: boldFont });
//     page.drawText('Kind', { x: 300, y: 310, size: fontSize, font: boldFont });
//     page.drawText('Status', { x: 400, y: 310, size: fontSize, font: boldFont });

//     // Transactions
//     page.drawText('visa', { x: 50, y: 290, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 254.98', { x: 150, y: 290, size: fontSize, font: timesRomanFont });
//     page.drawText('authorization', { x: 300, y: 290, size: fontSize, font: timesRomanFont });
//     page.drawText('success', { x: 400, y: 290, size: fontSize, font: timesRomanFont });

//     page.drawText('bogus', { x: 50, y: 270, size: fontSize, font: timesRomanFont });
//     page.drawText('Rs 254.98', { x: 150, y: 270, size: fontSize, font: timesRomanFont });
//     page.drawText('void', { x: 300, y: 270, size: fontSize, font: timesRomanFont });
//     page.drawText('success', { x: 400, y: 270, size: fontSize, font: timesRomanFont });

//     // Footer note
//     page.drawText('If you have any questions, please send an email to sharath@eywamedia.com', {
//         x: 50,
//         y: 240,
//         size: fontSize,
//         font: timesRomanFont,
//     });

//     // Generate unique name for the PDF
//     const uniqueFileName = `${uuidv4()}.pdf`;
//     const filePath = path.join(__dirname, uniqueFileName);

//     // Write the PDF to the filesystem
//     const pdfBytes = await pdfDoc.save();
//     fs.writeFileSync(filePath, pdfBytes);

//     console.log(`PDF created and saved as ${uniqueFileName}`);
// }