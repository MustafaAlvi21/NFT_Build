const express = require('express');
const router = express.Router();
const axios = require("axios");
const fs = require('fs');
const { PDFDocument, rgb, StandardFonts } = require('pdf-lib');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

// Create an endpoint to generate and download the invoice PDF
router.get('/download-invoice/:orderId', async (req, res) => {
    const orderId = req.params.orderId;

    try {
        const orderData = await fetchOrder4uwell(orderId); // Fetch the order data
        const pdfFilePath = await createInvoicePDF(orderData); // Create PDF and get file path

        // Set the headers to trigger a file download
        res.setHeader('Content-Disposition', `attachment; filename=${path.basename(pdfFilePath)}`);
        res.setHeader('Content-Type', 'application/pdf');

        // Send the PDF file to the client
        const fileStream = fs.createReadStream(pdfFilePath);
        fileStream.pipe(res);
    } catch (error) {
        console.error('Error downloading invoice:', error);
        res.status(500).send('invalid order detiails');
    }
});

module.exports = router;



async function createInvoicePDF(data) {
  try {
    // Create a new PDFDocument
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([600, 800]);

    // Set up fonts
    const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
    const boldFont = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);

    const imagePath = path.resolve(__dirname, '../icon.png.png');
    const iconImageBytes = fs.readFileSync(imagePath);
    const iconImage = await pdfDoc.embedPng(iconImageBytes);

    const fontSize = 12;
    const boldFontSize = 14;

    // Draw the icon at the top of the invoice
    page.drawImage(iconImage, {
      x: 50, // Adjust as needed
      y: 720, // Adjust as needed
      width: 70,
      height: 70,
    });

    // Add header content
    page.drawText('Invoice', {
      x: 50,
      y: 700, // Adjusted y position to accommodate the icon
      size: boldFontSize,
      font: boldFont,
      color: rgb(0, 0, 0),
    });

    // Add sender information (from)
    page.drawText('From', { x: 50, y: 680, size: fontSize, font: boldFont });
    page.drawText(data?.from, { x: 50, y: 665, size: fontSize, font: timesRomanFont });
    page.drawText('India', { x: 50, y: 650, size: fontSize, font: timesRomanFont });

    // Add Bill to information
    page.drawText('Bill to', { x: 200, y: 680, size: fontSize, font: boldFont });
    page.drawText(data?.billingAddress?.first_name || "NA", { x: 200, y: 665, size: fontSize, font: timesRomanFont });
    page.drawText(data?.billingAddress?.address1 || "NA", { x: 200, y: 650, size: fontSize, font: timesRomanFont });
    page.drawText(`${data?.billingAddress?.city || "NA"} ${data?.billingAddress.province} ${data?.billingAddress.zip}`, { x: 200, y: 635, size: fontSize, font: timesRomanFont });
    page.drawText(data?.billingAddress?.country || "NA", { x: 200, y: 620, size: fontSize, font: timesRomanFont });

    // Add Ship to information
    page.drawText('Ship to', { x: 400, y: 680, size: fontSize, font: boldFont });
    page.drawText('Steve Shipper', { x: 400, y: 665, size: fontSize, font: timesRomanFont });
    page.drawText('123 Shipping Street', { x: 400, y: 650, size: fontSize, font: timesRomanFont });
    page.drawText('Shippington KY 40003', { x: 400, y: 635, size: fontSize, font: timesRomanFont });
    page.drawText('United States', { x: 400, y: 620, size: fontSize, font: timesRomanFont });

    // Add Order number and date
    page.drawText(`Order ${data?.orderName}`, { x: 400, y: 765, size: fontSize, font: timesRomanFont });
    page.drawText(data?.orderDate, { x: 400, y: 750, size: fontSize, font: timesRomanFont });

    // Draw line above Order Details
    page.drawLine({
      start: { x: 50, y: 559 },
      end: { x: 550, y: 559 },
      thickness: 1,
      color: rgb(0, 0, 0),
    });

    // Order Details Section
    page.drawText('Order Details', { x: 50, y: 540, size: boldFontSize, font: boldFont });

    const orderDetailsStartY = 520;
    const rowHeight = 20;
    let currentY = orderDetailsStartY;

    // Table Header
    page.drawText('Qty', { x: 50, y: currentY, size: fontSize, font: boldFont });
    page.drawText('Item', { x: 150, y: currentY, size: fontSize, font: boldFont });
    page.drawText('Price', { x: 500, y: currentY, size: fontSize, font: boldFont });

    // Draw line under table header
    page.drawLine({
      start: { x: 50, y: currentY - 10 },
      end: { x: 550, y: currentY - 10 },
      thickness: 1,
      color: rgb(0, 0, 0),
    });

    currentY -= rowHeight;

    // Draw Order Items and adjust box height dynamically
    for (let i = 0; i < data?.orderDetails.length; i++) {
      const qty = String(data?.orderDetails[i].quantity);
      const item = data?.orderDetails[i].title;
      const price = String(data?.orderDetails[i].price);

      page.drawText(qty, { x: 50, y: currentY, size: fontSize, font: timesRomanFont });
      page.drawText(item, { x: 150, y: currentY, size: fontSize, font: timesRomanFont });
      page.drawText(`${price}`, { x: 495, y: currentY, size: fontSize, font: timesRomanFont });
      // page.drawText(`₹ ${price}`, { x: 480, y: currentY, size: fontSize, font: timesRomanFont });

      // Draw horizontal lines between rows
      page.drawLine({
        start: { x: 50, y: currentY - 10 },
        end: { x: 550, y: currentY - 10 },
        thickness: 0.5,
        color: rgb(0, 0, 0),
      });

      currentY -= rowHeight;
    }

    // Adjust table height based on the content
    const tableHeight = orderDetailsStartY - currentY + rowHeight;

    // Draw the enclosing box for the order details and totals
    page.drawRectangle({
      x: 45,
      y: currentY - 105, // Allow extra space for totals
      width: 510,
      height: tableHeight + 100, // Dynamic table height + extra space for totals
      borderColor: rgb(0, 0, 0),
      borderWidth: 1,
    });

    // Move down to leave space for totals
    currentY -= 40;

    // Summary Details inside the same box
    page.drawText('Subtotal', { x: 400, y: currentY, size: fontSize, font: timesRomanFont });
    page.drawText(data?.subTotal, { x: 500, y: currentY, size: fontSize, font: timesRomanFont });

    currentY -= rowHeight;
    page.drawText('Tax', { x: 400, y: currentY, size: fontSize, font: boldFont });
    page.drawText(data?.tax, { x: 500, y: currentY, size: fontSize, font: timesRomanFont });

    currentY -= rowHeight;
    page.drawText('Total', { x: 400, y: currentY, size: fontSize, font: boldFont });
    page.drawText(data?.total, { x: 500, y: currentY, size: fontSize, font: timesRomanFont });

    // Footer note
    page.drawText('If you have any questions, please send an email to sharath@eywamedia.com', {
      x: 50,
      y: 180,
      size: fontSize,
      font: timesRomanFont,
    });

    // Generate unique name for the PDF
    const uniqueFileName = `${uuidv4()}.pdf`;
    const filePath = path.join(__dirname, '..', uniqueFileName);

    // Write the PDF to the filesystem
    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync(filePath, pdfBytes);

    console.log(`PDF created and saved as ${uniqueFileName}`);
    return filePath; // Return the path of the created PDF
  } catch (e) {
    console.log("Invalid details in order:", e);
  }
}



async function fetchOrder4uwell(orderId) {
    const url = `https://${process.env.APIKRYClient}:${process.env.Admin_API_access_token_Client}@${process.env.storenameClient}.myshopify.com/admin/api/2024-10/orders/${orderId}.json`;
    try {
        const response = await axios.get(url);
        console.log("response", response.data.order);

        const data = {
            from: response?.data?.order?.line_items[0]?.vendor,
            shippingAddress: response?.data?.order?.shipping_address,
            shippingLines: response?.data?.order?.shipping_lines,
            billingAddress: response?.data?.order?.billing_address,
            orderName: response?.data?.order?.name,
            orderDate: response?.data?.order?.created_at,
            orderDetails: response?.data?.order?.line_items,
            subTotal: response?.data?.order?.current_subtotal_price,
            total: response?.data?.order?.total_price,
            tax: response?.data?.order?.current_total_tax
        };

        console.log("EXTRACTED data", data);
        return data;
    } catch (error) {
        console.error('Error order:', error);
        throw error;
    }
}




