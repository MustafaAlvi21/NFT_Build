const express = require('express');
const router = express.Router();
const axios = require("axios");
const fs = require('fs');
const PDFDocument = require('pdfkit');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const orderModel = require("../models/order")
const cron = require('node-cron');


router.get('/download-invoice', async (req, res) => {
  try {

    console.log("req.query", req.query);
    const { orderName } = req.query

    if (!orderName || orderName == "" || orderName == null || typeof orderName == undefined) {
      throw "order name required"
    }

    const orderData = await getOrderDetails(`#${orderName}`); // Fetch the order data

    console.log("orderData", orderData);

    if (orderData == null) {
      throw "invalid order details"
    }


    const pdfFilePath = await generateInvoice(orderData); // Create PDF and get file path
    // const pdfFilePath = await createInvoicePDF(orderData); // Create PDF and get file path

    console.log("pdfFilePath",pdfFilePath);
    

    res.setHeader('Content-Disposition', `attachment; filename=${path.basename(pdfFilePath)}`);
    res.setHeader('Content-Type', 'application/pdf');

    const fileStream = fs.createReadStream(pdfFilePath);
    fileStream.pipe(res);

  } catch (error) {
    console.error('Error downloading invoice:', error);
    res.status(500).send('invalid order detiails');
  }
});








router.post("/webhook", async (req, res) => {
  try {

    console.log("Webhook called with data:", req.body);
    console.log("Webhook called with name:", req.body.name);
    const saveData = await orderModel.create({ data: req.body })
    res.status(200).send('This is a correct JSON callback');

  }
  catch (e) {
    console.error("Webhook error:", e.message);
    res.status(422).send('Incorrect data');
  }
})





const getOrderDetails = async (name) => {
  try {
    console.log("called");

    const checkData = await orderModel.findOne({ "data.name": name })
    console.log("checkData", checkData);

    if (checkData == null) {
      return null
    }

    const data = {
      from: checkData.data.line_items[0].vendor,
      shippingAddress: checkData.data.shipping_address,
      shippingLines: checkData.data.shipping_lines,
      billingAddress: checkData.data.billing_address,
      orderName: checkData.data.name,
      orderDate: checkData.data.created_at,
      orderDetails: checkData.data.line_items,
      subTotal: checkData.data.current_subtotal_price,
      total: checkData.data.total_price,
      tax: checkData.data.current_total_tax,
      discount: checkData.data.total_discounts
    };

    console.log("extracted data", data);

    return data
  }
  catch (e) {
    console.log(e);
  }
}




cron.schedule('*/1 * * * *', () => {
  const pdfDir = path.join(__dirname, '..', 'pdfs');
  console.log('Running cron job to delete files in pdfs folder...');
  // Read all files in the 'pdfs' directory
  fs.readdir(pdfDir, (err, files) => {
    if (err) {
      return console.log('Unable to scan directory: ' + err);
    }
    // Loop through the files and delete each one
    files.forEach((file) => {
      const filePath = path.join(pdfDir, file);
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error(`Failed to delete file ${file}:`, err);
        } else {
          console.log(`Successfully deleted ${file}`);
        }
      });
    });
  });
});




function formatDate(dateString) {
  // Create a new Date object from the input string
  const date = new Date(dateString);
  
  // Get the day, month, and year
  const day = String(date.getDate()).padStart(2, '0'); // Pad day with leading zero if needed
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based, so add 1
  const year = date.getFullYear();

  // Return the formatted date
  return `${day}/${month}/${year}`;
}



function generateInvoice(data) {

  console.log("data",data);
  
  const doc = new PDFDocument({ size: 'A4', margin: 50 });

  const uniqueFileName = `${uuidv4()}.pdf`;

    const pdfDir = path.join(__dirname, '..', 'pdfs');

    // Check if the 'pdfs' folder exists, if not, create it
    if (!fs.existsSync(pdfDir)) {
      fs.mkdirSync(pdfDir);
    }

    // const filePath = path.join(__dirname, '..', uniqueFileName);

    const filePath = path.join(__dirname, '..', 'pdfs', uniqueFileName); // Save in the 'pdfs' folder


  // Pipe the PDF to a file
  doc.pipe(fs.createWriteStream(filePath));

  // // Pipe the PDF to a file
  // doc.pipe(fs.createWriteStream('invoice.pdf'));

  // Add logo
  doc.image('icon.png.png', 50, 45, { width: 60 });

 // Header Section
const headerHeight1 = 70; // Adjust the height as needed
const headerWidth1 = 150; // Width of the header box
const borderRadius1 = 5; // Radius for rounded corners

// Draw the header background with rounded corners
doc.roundedRect(400, 50, headerWidth1, headerHeight1, borderRadius1) // x, y, width, height, border radius
    .fill('#5c2d91') // Green background
    .stroke(); // Optional: if you want to outline the border

// Header Details
doc.fillColor('#ffffff') // Set text color to white
    .fontSize(20)
    .text('Invoice', 410, 50 + 10, { align: 'left' })  // Larger "Invoice" text
    .fontSize(10)
    .text(`Invoice Number: ${data?.orderName}`, 410, 75 + 10, { align: 'left' })  // Adjusted position
    .text(`Invoice Date: ${formatDate(data?.orderDate)}`, 410, 90 + 10, { align: 'left' });

    

  // Dashed Line separator
  doc.strokeColor('#5c2d91')
    .moveTo(50, 150)
    .lineTo(250, 150)
    .dash(5, { space: 5 })
    .stroke();

  doc.strokeColor('#5c2d91')
  .moveTo(300, 150)
    .lineTo(550, 150)
    .dash(5, { space: 5 })
    .stroke();

  doc.strokeColor('#5c2d91')
  .moveTo(50, 230)
    .lineTo(250, 230)
    .dash(5, { space: 5 })
    .stroke();

  doc.strokeColor('#5c2d91')
  .moveTo(300, 230)
    .lineTo(550, 230)
    .dash(5, { space: 5 })
    .stroke();



  // Invoice To
  doc.fontSize(10)
    .fillColor('#000000') // Default text color
    .text('Invoice To:', 50, 130)
    .text(data?.billingAddress.first_name, 50, 155)
    .text('demo@invoiceninja.com', 50, 170)
    .text(data?.billingAddress.address1, 50, 185)
    .text(`${data?.billingAddress.city} , ${data?.billingAddress.province} , ${data?.billingAddress.zip}`, 50, 200);


  // From
  doc.text('From:', 300, 130)
    .text('4UWell', 300, 155)
    .text('info@4uwell.com', 300, 170)
    .text('AVE Food and Beverages Pvt. Ltd.', 300, 185)
    .text('Bengaluru - 562 107, INDIA', 300, 200)
    .text('8925868082', 300, 215);

  // Table Header
  const tableTop = 250;
  const headerHeight = 20; // Height of the header
  const borderRadius = 5; // Radius for rounded corners

  // Draw the header background with rounded corners
  doc.roundedRect(50, tableTop, 500, headerHeight, borderRadius) // Adjust width as needed
    .fill('#5c2d91') // Green background
    .stroke();

  // Set text color to white
  doc.fillColor('#ffffff')
    .fontSize(10)
    .text('Item', 50 + 5, tableTop + 5) // Add some padding
    .text('Quantity', 370 + 5, tableTop + 5)
    .text('Total', 450 + 5, tableTop + 5);

  // Reset text color for the rest of the document
  doc.fillColor('#000000');


  // let data = [
  //   {
  //     item: "sticker",
  //     qty: "1",
  //     price: "20"
  //   },
  //   {
  //     item: "sofa",
  //     qty: "1",
  //     price: "1000"
  //   },
  //   {
  //     item: "green chilli",
  //     qty: "10",
  //     price: "300"
  //   },
    
  // ]

  let position = tableTop + 30;
 
  const currencySymbol = "INR"

  data?.orderDetails.forEach((item)=>{
  
  const totalPrice = parseFloat(item.price)*parseFloat(item.quantity)
    doc.text(item.title, 50, position)
    .text(String(item.quantity), 380, position)
    .text(`${currencySymbol} ${String(totalPrice)}`, 460, position);
    
    doc.moveTo(50, position + 15)
    .lineTo(550, position + 15)
    .dash(5, { space: 5 })
    .stroke();

    position += 25;
  })
  

  // Total Section
  doc.fontSize(10)
    .fillColor('#5c2d91') // Green color for totals
    .text(`Subtotal: ${currencySymbol} ${data?.subTotal}`, 400, position + 50)
    .text(`Tax: ${currencySymbol} ${data?.tax}`, 400, position + 65)
    .text(`Discount: ${currencySymbol} ${data?.discount}`, 400, position + 80);

  // Balance Due Box
  doc.roundedRect(400, position + 95, 140, 20, 5)
    .fill('#5c2d91')
    .fillColor('#ffffff')
    .text(`Total: ${currencySymbol} ${data?.total}`, 410, position + 100);

 
  // Finalize the PDF and end the stream
  doc.end();

  return filePath;
}





module.exports = router;