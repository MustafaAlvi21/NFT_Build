const mongoose = require("mongoose");

const orders = new mongoose.Schema({
    data: { type: Object, required: true },
    timestamp: { type: Number, default: Date.now, required: true }
});


module.exports = mongoose.model("orders", orders);