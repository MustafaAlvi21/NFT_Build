// QUERY SERVICES
const { createUserService } = require('./services/user-services')
const { createPlatformService } = require('./services/platform-services')
const { countPackagesService, createPackageService } = require('./services/package-services')
const { createComissionLevelService, countComissionLevelService } = require('./services/comissionLevel-services')


const createAutoData = async () => {
    const packagesCount = await countPackagesService()
    const comissionLevelCount = await countComissionLevelService()

    if (packagesCount == 0 && comissionLevelCount == 0) {
        await createComissionLevelService({ index: 1, fees: 5 })
        await createComissionLevelService({ index: 2, fees: 5 })
        await createComissionLevelService({ index: 3, fees: 4 })
        await createComissionLevelService({ index: 4, fees: 3 })
        await createComissionLevelService({ index: 5, fees: 2 })

        await createPlatformService({ plisioKey: '-ZHQeRD6YH_6dz2X8R1ElzOrmeKWA8dGVF0NO8yxM71X8_ZdHUUttAMQ6sKeOQ5C' })

        await createUserService({ walletAddress: "0xCc4c9Ce4cA8D4cD851f884a22730D4fD1e7b7188", referralCode: "admin-420", role: "admin" })
    }
}



module.exports = { createAutoData }